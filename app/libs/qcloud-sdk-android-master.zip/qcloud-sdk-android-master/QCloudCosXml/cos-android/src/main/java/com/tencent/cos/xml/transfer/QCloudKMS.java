package com.tencent.cos.xml.transfer;

/**
 * <p>
 * Created by rickenwang on 2021/6/24.
 * Copyright 2010-2021 Tencent Cloud. All Rights Reserved.
 */
public class QCloudKMS {
}
