package com.tencent.cos.xml.model.bucket;

import com.tencent.cos.xml.model.CosXmlResult;

/**
 * <p>
 * Created by rickenwang on 2020/10/9.
 * Copyright 2010-2020 Tencent Cloud. All Rights Reserved.
 */
public class PutBucketIntelligentTieringResult extends CosXmlResult {

}
