package com.qcloud.cos.model;

public class CiServiceResult extends CosServiceResult{

}
