package com.qcloud.cos.model.ciModel.auditing;

/**
 * 广告审核信息实体类
 */
public class AdsInfo extends AudtingCommonInfo {
}
