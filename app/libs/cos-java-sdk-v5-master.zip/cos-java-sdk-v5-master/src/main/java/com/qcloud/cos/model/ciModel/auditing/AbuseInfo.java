package com.qcloud.cos.model.ciModel.auditing;

/**
 * 审核场景为谩骂的审核结果信息
 */
public class AbuseInfo extends AudtingCommonInfo {
}
