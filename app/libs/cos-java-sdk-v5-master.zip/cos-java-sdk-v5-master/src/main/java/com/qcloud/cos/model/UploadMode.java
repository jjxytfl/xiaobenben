package com.qcloud.cos.model;

public enum UploadMode {
    APPEND_OBJECT,
    PUT_OBJECT;
}
