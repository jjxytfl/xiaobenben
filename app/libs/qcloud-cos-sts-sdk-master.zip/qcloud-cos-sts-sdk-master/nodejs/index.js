var sts = require('./sdk/sts');

module.exports = sts;