package com.tencent.cloud.cos.util;

public class Util {

//    public static final String DEFAULT_STS_HOST = "sts.tencentcloudapi.com";
    public static final String DEFAULT_STS_INTERNAL_HOST = "sts.internal.tencentcloudapi.com";
    public static final String CONFIG_VALUE_SEPERATOR = ",";
}
